function CF_val = cost_function(Utry)
 
global PIL_ITA_pc VSL Lvect X0 N p k gamma_I gamma_A gamma_Q gamma_H alpha_I alpha_H u deltaT
Lvect = Utry;

t = 0:1:N-1;
XX = ode3('gatto_ode',t,X0);
 
S = XX(:,1);
E = XX(:,2)+XX(:,3)+XX(:,4);
P = XX(:,5)+XX(:,6)+XX(:,7)+XX(:,8);
I = XX(:,9)+XX(:,10)+XX(:,11);
A = XX(:,12)+XX(:,13)+XX(:,14);
D = XX(:,18);


CF_val = sum(u*PIL_ITA_pc.*Lvect.*(S+E+P+I+A) +(1-u)*D.*VSL);
    