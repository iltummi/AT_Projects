%% Gatto ode Simulated Annealing 
clc; clear;
%% load parameters

global delta_E delta_P sigma eta gamma_I gamma_A gamma_Q gamma_H alpha_I alpha_H xi X0 beta_P beta_I beta_A deltaT N Lvect g p PIL_ITA_pc VSL theta u switch_inf N_START deltaT

parameters_ODE;

%%% NO LOCKDOWN

N_START = 14;
Lvect = zeros(1, N_START);
time = 0:1:N_START-1; 

tic
Xnolk = ode3('gatto_ode',time,X0);
toc
X0 = Xnolk(end,:); 

%%% LOCKDOWN STRATEGY

N = 224 - N_START; %control horizon

U0 = 0.7*ones(fix(N/14),1);

lb = zeros(fix(N/14),1);        %lower bounds
ub = 0.8.*ones(fix(N/14),1);    %upper bounds

options = optimoptions('simulannealbnd','Display','iter','MaxIterations',300,'InitialTemperature',10000);%,'annealingboltz');
[Uvec,fval] = simulannealbnd(@step_cost_fun,U0,lb,ub,options);

%reset initial condition
X0 = [1-0.0000000833 0 0 0.0000000833 0 0 0 0 0 0 0 0 0 0 0 0 0 0];

%evolution
N= 224;
time = 0:1:N-1;
Lvect = zeros(1,N); %no lockdown
Xnolk = ode3('gatto_ode',time,X0);

Lvect = zeros(1,N_START);%lockdown strategy
i=0;
for jj= N_START:14:N-1
    i = i+1;
    U = fix(Uvec(i)*10);
    L = U/10;
    Lvect = [Lvect, L.*ones(1,14)];
end
XFin = ode3('gatto_ode',time,X0);


%% plot

figure('Name', 'CYCLIC LOCKDOWN ODE')
t4 = tiledlayout(4,1);
nexttile;plot(time,Lvect.*100,'r'); ylabel('Lockdown (%)'); ylim([0 100]);
nexttile;plot(time,Xnolk(:,1).*100); hold on; plot(time,XFin(:,1).*100,'r'); 
ylabel('S [%]');
nexttile; plot(time,Xnolk(:,15).*100); hold on; plot(time,XFin(:,15).*100,'r'); 
ylabel('H [%]');
nexttile; plot(time,Xnolk(:,18).*100); hold on; plot(time,XFin(:,18).*100,'r'); 
ylabel('D [%]');
title(t4,'Cyclic Lockdown'); xlabel(t4,'Time [days]');
legend({'No Lockdown' 'Lockdown Strategy'},'orientation','horizontal','location','Southouts');
