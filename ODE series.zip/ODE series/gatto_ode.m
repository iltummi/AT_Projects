%%% GATTO Model CASCATE DI ODE
function [Xdot] = gatto_ode(tt,X)
% (variabile tempo| variabile che sono gli stati dell'eq. differenziale, dimensione )

global delta_E delta_P sigma eta gamma_I gamma_A gamma_Q gamma_H alpha_I alpha_H xi X0 Lvect beta_P beta_I beta_A N theta

S = X(1);
E1 = X(2);
E2 = X(3);
E3 = X(4);
P1 = X(5);
P2 = X(6);
P3 = X(7);
P4 = X(8);
I1 = X(9);
I2 = X(10);
I3 = X(11);
A1 = X(12);
A2 = X(13);
A3 = X(14);
H = X(15);
Q = X(16);
R = X(17);
D = X(18);

%TOTALI
E = E1+E2+E3;
P = P1+P2+P3+P4;
I = I1+I2+I3;
A = A1+A2+A3;


L = Lvect(fix(tt)+1);

Xdot = zeros(16,1);
 
    %S
    Xdot(1) = -((beta_P*P+beta_A*A+beta_I*I)/(S+E+P+I+A+R))*S*(1-theta*L)^2;
    
    %E
    Xdot(2) = ((beta_P*P+beta_A*A+beta_I*I)/(S+E+P+I+A+R))*S*(1-theta*L)^2 - (delta_E)*E1;
    Xdot(3) = (delta_E)*E1 - (delta_E)*E2;
    Xdot(4) = (delta_E)*E2 - (delta_E)*E3;
    
    %P
    
    Xdot(5) = (delta_E)*E3 - (delta_P)*P1;
    Xdot(6) = (delta_P)*P1 - (delta_P)*P2;
    Xdot(7) = (delta_P)*P2 - (delta_P)*P3;
    Xdot(8) = (delta_P)*P3 - (delta_P)*P4;
    
    %I
    Xdot(9) = sigma*(delta_P)*P4 - [(eta+gamma_I+alpha_I)]*I1;
    Xdot(10) = [(eta+gamma_I+alpha_I)]*I1 - [(eta+gamma_I+alpha_I)]*I2;
    Xdot(11) = [(eta+gamma_I+alpha_I)]*I2 - [(eta+gamma_I+alpha_I)]*I3;

    
    %A
    Xdot(12) = (1-sigma)*(delta_P)*P4 - (gamma_A)*A1;
    Xdot(13) = gamma_A*A1 - gamma_A*A2;
    Xdot(14) = gamma_A*A2 - gamma_A*A3;
    
    %H
    Xdot(15) = (1-xi)*(eta)*I3 - [(gamma_H + alpha_H)]*H;

    
    %Q
    Xdot(16) = xi*(eta)*I3 - gamma_Q*Q;
    
    %R
    Xdot(17) = (gamma_I)*I3 + (gamma_A)*A3 + (gamma_H)*H+(gamma_Q)*Q;
    
    %D
    Xdot(18) = (alpha_I)*I3 + (alpha_H)*H;