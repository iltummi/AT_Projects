%% OPTIMAL LOCKDOWN WITH SIMULATED ANNEALING 
clc;

global delta_E delta_P sigma eta gamma_I gamma_A gamma_Q gamma_H alpha_I alpha_H xi X0 beta_P beta_I beta_A N Lvect g p PIL_ITA_pc VSL theta u

parameters_ODE;

%%% NO LOCKDOWN

N_START = 14;
Lvect = zeros(1,N_START);
time = 0:1:N_START-1; 

tic
Xnolk = ode3('gatto_ode',time,X0);
toc
X0 = Xnolk(end,:); %new initial condition

%%% LOCKDOWN STRATEGY 

N = 200 - N_START; % control horizon
time = 0:1:N-1;

U0 = U0_ms; %initial guess
lb = zeros(N,1);        %lower bounds
ub = 0.8.*ones(N,1);    %upper bounds

options = optimoptions('simulannealbnd','Display','iter','MaxIterations',300, 'InitialTemperature', 1000);%,'annealingboltz');
tic
[Uvec,fval] = simulannealbnd(@ODE_cost_fun,U0,lb,ub,options);
toc

%reset initial condition
X0 = [1-0.0000000833 0 0 0.0000000833 0 0 0 0 0 0 0 0 0 0 0 0 0 0];

%evolution
N= 200;
time = 0:1:N-1;
Lvect = zeros(1,N);
Xnolk = ode3('gatto_ode',time,X0);

Lvect = [zeros(1,N_START) Uvec'];
XFin = ode3('gatto_ode',time,X0);


Xnolk = [ Xnolk(:,1), [Xnolk(:,2)+Xnolk(:,3)+Xnolk(:,4)], [Xnolk(:,5)+Xnolk(:,6)+Xnolk(:,7)+Xnolk(:,8)], ...
     [Xnolk(:,9)+Xnolk(:,10)+Xnolk(:,11)], [Xnolk(:,12)+Xnolk(:,13)+Xnolk(:,14)], ...
     Xnolk(:,15), Xnolk(:,16), Xnolk(:,17), Xnolk(:,18)];
 
 XFin = [ XFin(:,1), [XFin(:,2)+XFin(:,3)+XFin(:,4)], [XFin(:,5)+XFin(:,6)+XFin(:,7)+XFin(:,8)], ...
     [XFin(:,9)+XFin(:,10)+XFin(:,11)], [XFin(:,12)+XFin(:,13)+XFin(:,14)], ...
     XFin(:,15), XFin(:,16), XFin(:,17), XFin(:,18)];

%% plot

% figure('Name', 'DECREASING LOCKDOWN ODE')
% t4 = tiledlayout(6,1);
% nexttile;plot(time,Lvect.*100,'r'); ylabel('Lockdown (%)'); ylim([0 100]);
% nexttile;plot(time,Xnolk(:,1).*100); hold on; plot(time,XFin(:,1).*100,'r'); 
% ylabel('S [%]');
% nexttile; plot(time,Xnolk(:,15).*100); hold on; plot(time,XFin(:,15).*100,'r'); 
% ylabel('H [%]');
% nexttile;plot(time,Xnolk(:,16).*100); hold on; plot(time,XFin(:,16).*100,'r'); 
% ylabel('Q [%]');
% nexttile;plot(time,Xnolk(:,17).*100); hold on; plot(time,XFin(:,17).*100,'r'); 
% ylabel('R [%]');
% nexttile; plot(time,Xnolk(:,18).*100); hold on; plot(time,XFin(:,18).*100,'r'); 
% ylabel('D [%]');
% title(t4,'Decresing Lockdown for S,H,Q,R,D'); xlabel(t4,'Time [days]');
% legend({'No Lockdown' 'Lockdown Strategy'},'orientation','horizontal','location','Southouts');
% 
% figure('Name','DEC LOCKDOWN ODE 2')
% t10 = tiledlayout(5,1);
% nexttile;plot(time,Lvect.*100,'r'); ylabel('Lockdown (%)'); ylim([0 100]);
% nexttile;plot(time,Xnolk(:,4).*100); hold on; plot(time,XFin(:,4).*100,'r'); 
% ylabel('E [%]');
% nexttile; plot(time,Xnolk(:,8).*100); hold on; plot(time,XFin(:,8).*100,'r'); 
% ylabel('P [%]');
% nexttile;plot(time,Xnolk(:,11).*100); hold on; plot(time,XFin(:,11).*100,'r'); 
% ylabel('I [%]');
% nexttile;plot(time,Xnolk(:,14).*100); hold on; plot(time,XFin(:,14).*100,'r'); 
% ylabel('A [%]');
% title(t4,'dec Lockdown for E,P,I,A ultimi'); xlabel(t4,'Time [days]');
% legend({'No Lockdown' 'Lockdown Strategy'},'orientation','horizontal','location','Southouts');

figure('Name', 'decr LOCKDOWN GATTO')
t4 = tiledlayout(10,1);
nexttile; plot(time,Lvect.*100,'r'); ylabel('Lockdown (%)'); ylim([0 100]);
nexttile; plot(time,Xnolk(:,1).*100); hold on; plot(time,XFin(:,1).*100,'r'); ylim([0 110]);
ylabel('S [%]');
nexttile; plot(time,Xnolk(:,2).*100); hold on; plot(time,XFin(:,2).*100,'r'); 
ylabel('E [%]');
nexttile; plot(time,Xnolk(:,3).*100); hold on; plot(time,XFin(:,3).*100,'r');
ylabel('P [%]');
nexttile; plot(time,Xnolk(:,4).*100); hold on; plot(time,XFin(:,4).*100,'r');
ylabel('I [%]');
nexttile; plot(time,Xnolk(:,5).*100); hold on; plot(time,XFin(:,5).*100,'r');
ylabel('A [%]');
nexttile; plot(time,Xnolk(:,6).*100); hold on; plot(time,XFin(:,6).*100,'r');
ylabel('H [%]');
nexttile; plot(time,Xnolk(:,7).*100); hold on; plot(time,XFin(:,7).*100,'r');
ylabel('Q [%]');
nexttile; plot(time,Xnolk(:,8).*100); hold on; plot(time,XFin(:,8).*100,'r');
ylabel('R [%]');
nexttile; plot(time,Xnolk(:,9).*100); hold on; plot(time,XFin(:,9).*100,'r');
ylabel('D [%]');
title(t4,'Optimal Lockdown'); xlabel(t4,'Time [days]');
legend({'No Lockdown' 'Optimal lockdown'},'orientation','horizontal','location','Southouts');