%% FREE RESPONSE

global delta_E delta_P sigma eta gamma_I gamma_A gamma_Q gamma_H alpha_I alpha_H xi X0 beta_P beta_I beta_A N Lvect g p PIL_ITA_pc VSL theta u

parameters_ODE; 

%% Model simulation for 200 days

N=200;
Lvect = zeros(1,N);
time = 0:1:N-1; 

Xnolk = ode3('gatto_ode',time,X0);

figure('Name', 'GATTO MODEL ODE SERIES')
hold on;
plot([0:N-1],Xnolk(:,1).*100,'k');  
plot([0:N-1],Xnolk(:,4).*100,'b');  
plot([0:N-1],Xnolk(:,8).*100,'g');  
plot([0:N-1],Xnolk(:,11).*100,'r');  
plot([0:N-1],Xnolk(:,14).*100,'c'); 
plot([0:N-1],Xnolk(:,15).*100,'m');  
plot([0:N-1],Xnolk(:,16).*100,'y');  
plot([0:N-1],Xnolk(:,17).*100,'o'); 
plot([0:N-1],Xnolk(:,18).*100,'-');  
legend({'S' 'E3' 'P4' 'I3' 'A3' 'H' 'Q' 'R' 'D'});
title('No lockdown ODE series'); xlabel('Time (days)'); ylabel('Population (%)');


% Gatto Model

Xnolk = [ Xnolk(:,1), [Xnolk(:,2)+Xnolk(:,3)+Xnolk(:,4)], [Xnolk(:,5)+Xnolk(:,6)+Xnolk(:,7)+Xnolk(:,8)], ...
     [Xnolk(:,9)+Xnolk(:,10)+Xnolk(:,11)], [Xnolk(:,12)+Xnolk(:,13)+Xnolk(:,14)], ...
     Xnolk(:,15), Xnolk(:,16), Xnolk(:,17), Xnolk(:,18)];
 
figure('Name', 'GATTO MODEL')
hold on;
plot([0:N-1],Xnolk(:,1).*100,'k');  
plot([0:N-1],Xnolk(:,2).*100,'b');  
plot([0:N-1],Xnolk(:,3).*100,'g');  
plot([0:N-1],Xnolk(:,4).*100,'r');  
plot([0:N-1],Xnolk(:,5).*100,'c');  
plot([0:N-1],Xnolk(:,6).*100,'m');  
plot([0:N-1],Xnolk(:,7).*100,'y');  
plot([0:N-1],Xnolk(:,8).*100,'o');  
plot([0:N-1],Xnolk(:,9).*100,'-');  
legend({'S' 'E' 'P' 'I' 'A' 'H' 'Q' 'R' 'D'});
title('No lockdown case'); xlabel('Time (days)'); ylabel('Population (%)');