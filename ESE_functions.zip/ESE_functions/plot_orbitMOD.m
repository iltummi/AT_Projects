function plot_orbitMOD(obj_id, annus)
% PLOT_ORBIT(obj_id, annus) plots the orbit of target planet OBJ_ID
%   during the year ANNUS.
%   It computes the planet day-by-day position for a complete
%   orbital revolution of the planet.
%
%   obj_id   - planet identifier:
%                1 = Mercury
%                2 = Venus
%                3 = Earth
%                4 = Mars
%                5 = Jupiter
%                6 = Saturn
%                7 = Uranus
%                8 = Neptune
%                9 = Pluto
%               10 = Enceladus
%               11 = Sun
%
%   annus    - year considered
%

    %Earth-days for a complete revolution of the planet
    year = [88 
            225 
            365 
            687 
            4330 
            10748 
            30666 
            60148 
            90560 
           1.370218 
            25];
        
    colors = ["g"          %green
              "m"          %magenta
              "b"          %blue
              "r"          %red
              "#A2142F"    %darker red
              "#7E2F8E"    %purple
              "#4DBEEE"    %darker cyan
              "c"          %(bright) cyan
              "#D95319"    %orange
              "#77AC30"    %darker green
              "#D95319"];  %orange, not visible due to Sun orbit dimensions
 	
          %Starting position at 1/1
    [~, r0, v0, ~] = planet_elements_and_svMOD(obj_id,annus,1,1,0,0,0);

    pos = [r0];
          
          
        if (obj_id==10)
            j0     = J0(annus, 1, 1);
            tf = 29*365;
            
            for i=0:tf
            j0=j0+1;
            [year, month, day]=G0(j0); 
            [x, v] = enceladus_pos(year, month, day, 0, 0, 0);
            plot3(x(1),x(2),x(3),'o', 'Color', colors(obj_id))
            end
        
        else
         
         for g = 1:year(obj_id)

            %Planet position day by day
            [r, ~] = rv_from_r0v0(r0, v0, g*60*60*24);
            pos = cat(1,pos,r);

         end
         
        %Orbit plot
        plot3(pos(:,1),pos(:,2),pos(:,3),'--', 'Color', colors(obj_id))


        end

end