%% Gatto Simulated Annealing

global delta_E delta_P sigma eta gamma_I gamma_A gamma_Q gamma_H alpha_I alpha_H...
    xi X0 beta_P beta_I beta_A N Lvect PIL_ITA_pc VSL theta u 

parameters;

%%% NO LOCKDOWN
N_START = 14;
Lvect = zeros(1,N_START);
time = 0:1:N_START-1; 

Xnolk = ode3('gatto',time,X0);
X0 = Xnolk(end,:); 

%%% OPTIMAL LOCKDOWN WITH SIMULATED ANNEALING 
N = 224 - N_START; %control horizon


U0 = 0.7*ones(fix(N/14),1);

lb = zeros(fix(N/14),1);        %lower bounds
ub = 0.7.*ones(fix(N/14),1);    %upper bounds

options = optimoptions('simulannealbnd','Display','iter','MaxIterations',300,'InitialTemperature',10000);%,'annealingboltz');
[Uvec,fval] = simulannealbnd(@step_cost_fun,U0,lb,ub,options);

%reset X0
X0 = [1-0.0000000833 0.0000000833 0 0 0 0 0 0 0];

%evolution
N= 224;
time = 0:1:N-1;
Lvect = zeros(1,N); %no lockdown
Xnolk = ode3('gatto',time,X0);

Lvect = zeros(1,N_START);%lockdown strategy
i=0;

for jj= N_START:14:N-1
    i = i+1;
    U = fix(Uvec(i)*10);
    if U < 2
        L = 0;
    elseif U < 4 && U > 2
        disp('yellow zone')
        L = 0.2;
    else
        disp('red zone')
        L = 0.7;
    end
    Lvect = [Lvect, L.*ones(1,14)];
end

XFin = ode3('gatto',time,X0);

%% plot
figure('Name','STEP FUNCTION STRATEGY')
t4 = tiledlayout(10,1);
nexttile; plot(time,Lvect.*100,'r'); ylabel('Lockdown (%)'); ylim([0 100]);
nexttile; plot(time,Xnolk(:,1).*100); hold on; plot(time,XFin(:,1).*100,'r'); 
ylabel('S [%]');
nexttile; plot(time,Xnolk(:,2).*100); hold on; plot(time,XFin(:,2).*100,'r'); 
ylabel('E [%]');
nexttile; plot(time,Xnolk(:,3).*100); hold on; plot(time,XFin(:,3).*100,'r'); 
ylabel('P [%]');
nexttile; plot(time,Xnolk(:,4).*100); hold on; plot(time,XFin(:,4).*100,'r'); 
ylabel('I [%]');
nexttile; plot(time,Xnolk(:,5).*100); hold on; plot(time,XFin(:,5).*100,'r'); 
ylabel('A [%]');
nexttile; plot(time,Xnolk(:,6).*100); hold on; plot(time,XFin(:,6).*100,'r'); 
ylabel('H [%]');
nexttile; plot(time,Xnolk(:,7).*100); hold on; plot(time,XFin(:,7).*100,'r'); 
ylabel('Q [%]');
nexttile; plot(time,Xnolk(:,8).*100); hold on; plot(time,XFin(:,8).*100,'r'); 
ylabel('R [%]');
nexttile; plot(time,Xnolk(:,9).*100); hold on; plot(time,XFin(:,9).*100,'r'); 
ylabel('D [%]');
title(t4,'Cyclic Lockdown'); xlabel(t4,'Time [days]');
legend({'No Lockdown' 'Cyclic lockdown'},'orientation','horizontal','location','Southouts');
