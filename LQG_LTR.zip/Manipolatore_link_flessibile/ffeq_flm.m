function y = ffeq_flm(x,mldmb)
%
% Funzione ausiliaria utilizzata 
% per determinare le radici dell'equazione di frequenza
%
cx = cos(x);
sx = sin(x);
chx = cosh(x);
shx = sinh(x);
y = 1 + chx*cx + mldmb*x*(shx*cx - chx*sx);