%INCERTEZZE NON STRUTTURATE

%syms m_L d_1 d_2 d_r
L = 1;    % m         length of the link
R = 0.04; % m         distance between the hub center and the link root 
%
parametri_flm   %           model parameters
i=0;

%Trovo il MODELLO NOMINALE
m_L = 0.25;
d_1 = 0.4;
d_2 = 10;
d_r = 0.15;

a0 = a0_1 + a0_2*m_L;
a1 = a1_1 + a1_2*m_L;
a2 = a2_1 + a2_2*m_L;
b1 = 1/(b1_1 + b1_2*m_L);
b2 = 1/(b2_1 + b2_2*m_L);
c1 = 1/(c1_1 + c1_2*m_L);
c2 = 1/(c2_1 + c2_2*m_L);
%
tol = 1e-8;
%
M = [a0 a1 a2 
     a1 1  0 
     a2 0  1 ];
Minv = inv(M);
N1 = diag([d_r d_1 d_2]);
N2 = diag([tol c1 c2]);
T = [1 0 0]';
intz = tf(1,[1 0]);
Int1 = blkdiag(intz, intz, intz);
Int2 = blkdiag(intz, intz, intz);
P1 = [1 b1 b2; 0 (L+R)*b1 (L+R)*b2];
P2 = [1 b1 b2];
Wa = tf(1,[0.004 1]);
%
systemnames = ' Minv N1 N2 T Int1 Int2 P1 P2 Wa';
inputvar = '[ tau ]';
outputvar = '[ P1(1) ]';
input_to_Wa = '[tau]';
input_to_Minv = '[ T - N1 - N2 ]';
input_to_N1 = '[ Int1 ]';
input_to_N2 = '[ Int2 ]';
input_to_T = '[ Wa ]';
input_to_Int1 = '[ Minv ]';
input_to_Int2 = '[ Int1 ]';
input_to_P1 = '[ Int2 ]';
input_to_P2 = '[ Minv ]';
Gn = sysic;
outputs = {'alpha'};
Gn.OutputName = outputs;

%Trovo il MODELLO INCERTO
figure(1)
hold on
%valuto l'andamento del modello incerto al variare dei parametri incerti
for m_L = [0.15 0.25 0.35]
    for d_1 = [0.24 0.4 0.56]
        for d_2 = [6 10 14]
            for d_r = [0.12 0.15 0.18]

a0 = a0_1 + a0_2*m_L;
a1 = a1_1 + a1_2*m_L;
a2 = a2_1 + a2_2*m_L;
b1 = 1/(b1_1 + b1_2*m_L);
b2 = 1/(b2_1 + b2_2*m_L);
c1 = 1/(c1_1 + c1_2*m_L);
c2 = 1/(c2_1 + c2_2*m_L);
%
tol = 1e-8;
%
M = [a0 a1 a2 
     a1 1  0 
     a2 0  1 ];
Minv = inv(M);
N1 = diag([d_r d_1 d_2]);
N2 = diag([tol c1 c2]);
T = [1 0 0]';
intz = tf(1,[1 0]);
Int1 = blkdiag(intz, intz, intz);
Int2 = blkdiag(intz, intz, intz);
P1 = [1 b1 b2; 0 (L+R)*b1 (L+R)*b2];
P2 = [1 b1 b2];
Wa = tf(1,[0.004 1]);
%
systemnames = ' Minv N1 N2 T Int1 Int2 P1 P2 Wa';
inputvar = '[ tau ]';
outputvar = '[ P1(1) ]';
input_to_Wa = '[tau]';
input_to_Minv = '[ T - N1 - N2 ]';
input_to_N1 = '[ Int1 ]';
input_to_N2 = '[ Int2 ]';
input_to_T = '[ Wa ]';
input_to_Int1 = '[ Minv ]';
input_to_Int2 = '[ Int1 ]';
input_to_P1 = '[ Int2 ]';
input_to_P2 = '[ Minv ]';
G = sysic;
outputs = {'alpha'};
G.OutputName = outputs;

%trovo l'andamento delle incertezze
L = (G - Gn)*inv(Gn);
sigma(L,'--k')

i=i+1;
            end
        end
    end
end

%approssimo con una funzione di trasferimento con 3 poli e 3 zeri ed un
%guadagno 0.01
s=tf('s')
lm=0.01*((1+s*1e9)*(1+s)*(1+s/0.68e3))/((1+s*0.32e8)*(1+s/22)*(1+s/100));
sigma(lm,'r')
grid
hold off
