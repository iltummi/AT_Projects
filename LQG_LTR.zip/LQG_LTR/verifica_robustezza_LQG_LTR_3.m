omega = logspace(0,4,100);
Gc_g = ufrd(Gc,omega);
opt = robopt('Display','on','Sensitivity','off');
[stabmarg,destabunc,report,info] = robuststab(Gc_g,opt);
stabmarg
report
semilogx(info.MussvBnds(1,1),'r',info.MussvBnds(1,2),'b--')
grid
title('Robust stability')
xlabel('Frequency (rad/s)')
ylabel('mu')
legend('\mu-upper bound','\mu-lower bound')