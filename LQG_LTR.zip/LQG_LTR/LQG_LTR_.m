
%CONTROLLORE LQG/LTR

modello_nominale
s=tf('s');

Phi=inv(s*eye(7)-A); %(sI-A)^-1

lm=0.01*((1+s*1e9)*(1+s)*(1+s/0.68e3))/((1+s*0.32e8)*(1+s/22)*(1+s/100)); 

p=1000*(1+s)/(1+s/1e-3);

%INPUT LOOP RECOVERY

figure(1);
sigma(lm)  % max freq di taglio è 3 
hold on
title('Trovo la frequenza di taglio')
legend('lm')
grid
hold off

%verifico se sono soddisfatti i requisiti....

%...di RP in BASSA FREQUENZA
H=0.1*eye(7);  %0.1
rho = 0.02;   %0.02

HPB = H*Phi*B;

figure(2)
sigma(1/sqrt(rho)*HPB)
hold on
sigma(p/(1-lm))
title('sigma(1/sqrt(rho)*HPB) > p/(1-lm)')
legend('1/sqrt(rho)*HPB','p/(1-lm')
grid
hold off

%...di RS in ALTA FREQUENZA
HB = H*B;
svds(HB/sqrt(rho),1,'smallest') % 2.8 < 3

%trovo le matrici H e R da cui ricavo il guadagno dell'LQR (Kc)
Q=H'*H;
R=rho;
[Kc,J,CLP] = lqr(G,Q,R);

%%
%verifico se i requisiti rimangono soddisfatti con il Kc trovato

%1/sqrt(rho))*HPB=KPB
KPB=Kc*Phi*B;
figure(3)
sigma(KPB)
hold on
sigma((1/sqrt(rho))*HPB)
title('1/sqrt(rho))*HPB=KPB')
legend('KPB','1/sqrt(rho))*HPB')
grid
hold off

%KPB>1/2
figure(4)
sigma(KPB,[],3) % >1/2 (-6 dB)
hold on
grid
title('KPB>1/2')
legend('KPB')
hold off

%KPB*inv(1+KPB)<1/lm
figure(5)
sigma(1/lm)
hold on
sigma(KPB*inv(1+KPB))
title('KPB*inv(1+KPB)<1/lm')
legend('1/lm','KPB*inv(1+KPB)')
grid
hold off


%% Effettuo il RECUPERO con il Filtro di Kalman
tzero(C*Phi*B); %sistema a fase minima
Gamma = B*B';
mu=1;
q  = [1 1e5 1e10 1e16]; 

[K_LTR,SVL,W1] = ltrsyn(G,Kc,Gamma,mu,q);

T_lq =K_LTR*G;

%verifico se sigma(K_LTR*G)=sigma(KPB)
figure(7)
sigma(T_lq,'r')
hold on
sigma(KPB,'b')
grid 
title('sigma(K_LTR*G)=sigma(KPB)')
legend('T_lq','KPB')
hold off

%verifico se sigma(I+inv(T_lq))>1/2
figure(8);
sigma(T_lq,[],3) % >1/2 (-6 dB)
hold on
grid
title('sigma(I+inv(T_lq))>1/2')
legend('I+inv(T_lq)')
hold off


