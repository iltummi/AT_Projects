% RISPOSTA IN FREQUENZA DEL f.l.m con controllore LQG/LTR

% Controller inputs:  1)  ref
%                     2)  alpha + noise1

sistema_con_controllore_ltr

clp = Gclp; %interconnessione a catena chiusa

%Risposta in frequenza a catena chiusa
ref_loop = clp(1,1); % from ref to alpha
omega = logspace(0,3,100);
figure(1)
bode(ref_loop,'b-',omega), grid
title('Bode plot of the closed-loop system')
legend('Closed-loop system')

%Frequenza di risposta di wL
wl_loop = clp(4,1); % from ref to wL
omega = logspace(-1,3,100);
figure(2)
bode(wl_loop,omega), grid
title('wL frequency response')

% Sensitività di uscita al disturbo
sen_loop = clp(1,2); % from dist to alpha
omega = logspace(-3,3,300);
figure(3)
bodemag(sen_loop,'r',omega), grid
title('Sensitivity to the disturbance')
%
% Sensitività di uscita al rumore 1
noise1_loop = clp(1,3); % from noise1 to alpha
omega = logspace(-2,3,100);
figure(4)
bodemag(noise1_loop,'r-',omega), grid
title('Sensitivity to the noise 1')

%Frequenza di risposta del controllore
omega = logspace(-3,3,300);
figure(6)
bode(K,'r-',omega), grid
title('Controller Bode plot')
legend('K')

