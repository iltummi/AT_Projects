 %% SEPIA parameters
syms beta_P beta_I beta_A 
R_0 = 3.6; %reproduction rate at t=0
delta_E = 1/3.32; %rate at which the EXPOSED people become PRESYMPTOMATIC
inv_delta_E = 1/delta_E;

delta_P = 1/0.75; % rate at which PRESYMPTOMATICS become SERIOUSLY INFECTED
inv_delta_P = 1/delta_P;

sigma = 0.25; % probability with which PRESYMPTOMATICS become SERIOUS INFECTED
eta = 1/4.05; % rate at which SERIOUS INFECTED are isolated
inv_eta = 1/eta;

csi = 0.4;  % fraction of SERIOUS INFECTIONS going to quarantine

%% In order to reduce the number of parameters to be estimated it is necessary: 
 
    % gamma_H=gamma_Q=gamma_I 
    % gamma_A = 2*gamma_I
    % alfa_I=alfa_H
    
gamma_I  = 1/14.32; % rate at which SERIOUS INFECTIONS recover from infection
inv_gamma_I = 1/gamma_I;
gamma_H = 1/14.32; % rate at which HOSPITALIZEDs recover from infection
gamma_Q =  1/14.32; % rate at which those in QUARANTINE recover from infection
gamma_A = 2*gamma_I; % rate at which ASYMPTOMATICS recover from infection
 
alpha_I = 1/24.23 ; % rate at which SERIOUS INFECTED dies
inv_alfa_I = 1/alfa_I;
alpha_H = 1/24.23 ; % rate at which HOSPITALIZEDs die

X0 = [1-0.0000000833 0.0000000833 0 0 0 0 0 0 0];

bA_su_bP = 0.033;
bI_su_bA = 1.03;

S0=X0(1);
E0=X0(2);
P0=X0(3);
I0=X0(4);
A0=X0(5);
H0=X0(6);
Q0=X0(7);
R0=X0(8);
D0=X0(9);