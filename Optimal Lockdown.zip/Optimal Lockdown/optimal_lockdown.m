%% OPTIMAL LOCKDOWN WITH SIMULATED ANNEALING 

global delta_E delta_P sigma eta gamma_I gamma_A gamma_Q gamma_H alpha_I alpha_H...
    xi X0 beta_P beta_I beta_A N Lvect PIL_ITA_pc VSL theta u 

parameters;
u=0.2;

%%% NO LOCKDOWN FOR 14 DAYS

N_START = 14;
Lvect = zeros(1,N_START);
time = 0:1:N_START-1; 

Xnolk_14 = ode3('gatto',time,X0);

X0 = Xnolk_14(end,:); %new initial condition

%%% OPTIMAL LOCKDOWN STRATEGY

N = 200 - N_START; % control horizon
time = 0:1:N-1;
 
U0 = U0_ms; %initial guess
lb = zeros(N,1);        %lower bounds
ub = 0.7.*ones(N,1);    %upper bounds

options = optimoptions('simulannealbnd','Display','iter','MaxIterations',300,'InitialTemperature',10000);
[Uvec,fval] = simulannealbnd(@cost_fun_sa,U0,lb,ub,options);
 
% RESET INITIAL CONDITIONS
X0 = [1-0.0000000833 0.0000000833 0 0 0 0 0 0 0];  %S E P I A H Q R D 
 
%evolution
N= 200;
time = 0:1:N-1;
Lvect = zeros(1,N);
Xnolk = ode3('gatto',time,X0);
 
Lvect = [zeros(1,N_START) Uvec'];
XFin = ode3('gatto',time,X0);
 
%%% PLOT
figure('Name', 'OPTIMAL LOCKDOWN GATTO')
t4 = tiledlayout(10,1);
nexttile; plot(time,Lvect.*100,'r'); ylabel('Lockdown (%)'); ylim([0 100]);
nexttile; plot(time,Xnolk(:,1).*100); hold on; plot(time,XFin(:,1).*100,'r'); ylim([0 110]);
ylabel('S [%]');
nexttile; plot(time,Xnolk(:,2).*100); hold on; plot(time,XFin(:,2).*100,'r'); 
ylabel('E [%]');
nexttile; plot(time,Xnolk(:,3).*100); hold on; plot(time,XFin(:,3).*100,'r');
ylabel('P [%]');
nexttile; plot(time,Xnolk(:,4).*100); hold on; plot(time,XFin(:,4).*100,'r');
ylabel('I [%]');
nexttile; plot(time,Xnolk(:,5).*100); hold on; plot(time,XFin(:,5).*100,'r');
ylabel('A [%]');
nexttile; plot(time,Xnolk(:,6).*100); hold on; plot(time,XFin(:,6).*100,'r');
ylabel('H [%]');
nexttile; plot(time,Xnolk(:,7).*100); hold on; plot(time,XFin(:,7).*100,'r');
ylabel('Q [%]');
nexttile; plot(time,Xnolk(:,8).*100); hold on; plot(time,XFin(:,8).*100,'r');
ylabel('R [%]');
nexttile; plot(time,Xnolk(:,9).*100); hold on; plot(time,XFin(:,9).*100,'r');
ylabel('D [%]');
title(t4,'Optimal Lockdown'); xlabel(t4,'Time [days]');
legend({'No Lockdown' 'Optimal lockdown'},'orientation','horizontal','location','Southouts');
