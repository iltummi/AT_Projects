%CONTROLLO ROBUSTO DI UN MANIPOLATORE A LINK FLESSIBILE

%%
%Determino il MODELLO INCERTO 
    
    %queste sono le INC. STRUTTURATE che conosco:
    m_L = ureal('m_L',0.25,'percentage',40);  % kg        massa del carico
    d_1 = ureal('d_1',0.4,'percentage',40);   % kg.m^2/s  fattore di smorzamento
    d_2 = ureal('d_2',10,'percentage',40);    % kg.m^2/s  fattore di smorzamento
    d_r = ureal('d_r',0.15,'percentage',20);  % kg.m^2/s  coeff. di attrito del mozzo
    
    L = 1;    % m        lunghezza del link
    R = 0.04; % m        distanza tra mozzo centrale e origine del link

    %PARAMETRI DEL MODELLO:
   
    parametri_flm   
    
    a0 = a0_1 + a0_2*m_L;
    a1 = a1_1 + a1_2*m_L;
    a2 = a2_1 + a2_2*m_L;
    b1 = 1/(b1_1 + b1_2*m_L);
    b2 = 1/(b2_1 + b2_2*m_L);
    c1 = 1/(c1_1 + c1_2*m_L);
    c2 = 1/(c2_1 + c2_2*m_L);

    tol = 1e-8;
    
    %Scrivo le matrici che andranno a costituire il modello incerto:
    M = [a0 a1 a2 
     a1 1  0 
     a2 0  1 ];
    Minv = inv(M);

    N1 = diag([d_r d_1 d_2]);
    N2 = diag([tol c1 c2]);

    T = [1 0 0]';

    intz = tf(1,[1 0]); %è l'integratore 1/s
    Int1 = blkdiag(intz, intz, intz); %è una matrice diagonale di integratori
    Int2 = blkdiag(intz, intz, intz); %idem

    P1 = [1 b1 b2; 0 (L+R)*b1 (L+R)*b2];
    P2 = [1 b1 b2];

%uso il comando 'SYSIC' per costruire il modello incerto:
systemnames = ' Minv N1 N2 T Int1 Int2 P1 P2 '; %tutti i sistemi che devono essere interconnessi
inputvar = '[ tau ]';
outputvar = '[P1(1); Int2(1); P2; P1(2)]';
input_to_Minv = '[T -N1 -N2]';
input_to_N1 = '[ Int1 ]';
input_to_N2 = '[ Int2 ]';
input_to_T = '[ tau ]';
input_to_Int1 = '[ Minv ]';
input_to_Int2 = '[ Int1 ]';
input_to_P1 = '[ Int2 ]';
input_to_P2 = '[ Minv ]';
G = sysic
outputs = {'alpha' 'theta' 'ddalpha' 'wL'};
G.OutputName = outputs;

%ho ridotto il modello incerto, infatti mL qui si ripete 10 volte
%invece delle 32 ripetizioni presenti nel modello incerto descritto
%dalle equazioni

%%

%Funzioni di peso delle prestazioni del controllore non collocato per il
% f.l.m.

% Modello della funzione di trasferimento
M= tf(625, [1 50 625]);

% Funzione di peso delle prestazioni 
Wp = tf([1 25 150], [1 22 0.15]);

% Funzioni di peso del controllo 
Wu = 10^(-3)*tf(1);

% Filtro antirumore Wn1
Wn1 = 0.00001*tf([0.5 1], [0.005 1]);

% Filtro antirumore Wn2
Wn2 = 0.001*tf([1 1], [0.01 1]);



%Genero l'interconnessione a catena aperta:

    %Funzione di trasferimento dell'attuatore
    Wa = tf(1,[0.004 1]);
    
%Uso nuovamente il comando 'SYSIC' per interconnettere i blocchi:
systemnames = ' G Wa M Wn1 Wn2 Wp Wu ';
inputvar = '[ ref; dist; noise{2}; control ]';
outputvar = '[ Wp; Wu; ref; G(2) + Wn1; G(3) + Wn2 ]';
input_to_G = '[ Wa - dist ]';
input_to_Wa = '[ control ]';
input_to_M = '[ ref ]';
input_to_Wn1 = '[ noise(1) ]';
input_to_Wn2 = '[ noise(2) ]';
input_to_Wp = '[ G(1) - M ]';
input_to_Wu = '[ control ]';
sys_ic = sysic
outputs = {'e_p' 'e_u' 'ref' 'y_s(1)' 'y_s(2)'};
sys_ic.OutputName = outputs;

%%
%Illustro vari diagrammi di Bode e le risposte in frequenza:

%Confronto tra diagrm di Bode esatto e approssimato del modello del manipolatore: 
omega = logspace(0,3,300); %genera 300 punti equamente spaziati tra le decadi
figure(1)
olp_ic1 = G(1,1);  %considero il modello CON INPUT TAU e OUTPUT ALPHA
bode(olp_ic1.Nominal,'r-',olp_ic1,'b--',omega), grid
title('Diagr. di Bode tra modello esatto e approssimato')
legend('Nominal system','Random samples','3')

omega = logspace(0,3,300);
figure(2)
olp_ic2 = G(2,1);  %%considero il modello CON INPUT TAU e OUTPUT THETA
bode(olp_ic2.Nominal,'r-',olp_ic2,'b--',omega), grid
title('Diagr. di Bode tra modello esatto e approssimato')
legend('Nominal system','Random samples','1')

omega = logspace(0,3,300);
figure(3)
olp_ic4 = G(4,1);  %considero il modello CON INPUT TAU e OUTPUT wL
bode(olp_ic4.Nominal,'r-',olp_ic4,'b--',omega), grid
title('Diagr. di Bode tra modello esatto e approssimato')
legend('Nominal system','Random samples','3')

%%
%Eseguo la SINTESI MU per il progetto del controllore

nmeas = 3; %uscite di mu_ic
ncont = 1; % ingressi di mu_ic

mu_ic = usubs(sys_ic,'m_L','Nom'); %dato che trascuro il blocco 8x8 delle 
% incertezze relative a m_L (poichè causa la non convergenza
% dell'iterazione D-K, gli assegno il valore nominale ---->
% ---> mu_ic = è il modello incerto dello spazio di stato(a cui ho
% assegnato ad m_L il valore nominale) 

fv = logspace(-1,3,100);%genera1300 punti equamente spaziati tra le decadi
% 10^-1 e 10^3

%eseguo la sintesi mu col comando 'DKSYN':
opt = dkitopt('FrequencyVector',fv,...       
              'DisplayWhileAutoIter','on',...
              'NumberOfAutoIterations',3)
   
[K_mu,CL_mu,bnd_mu,dkinfo] = dksyn(mu_ic,nmeas,ncont,opt);

K = K_mu;
[Ak,Bk,Ck,Dk] = ssdata(K); %ricavo le matrici dello spazio di stato di K


%%
%ANALISI della STABILITA' ROBUSTA
 
    if size(K,2) == 2 %se la lunghezza della seconda dimensione di K è 2 allora....

        cls = lft(sys_ic_PD,K,1,2); % uso un controllore PD 

       %faccio la TRASF.LIN.FRATTA tra sys_ic_PD e K---> do la prima
       %uscita di K all'ultimo ingresso di sys_ic_PD e le ultime 2 uscite di
       %sys_ic_PD le do ai primi 2 ingressi di K

    elseif size(K,2) == 3 %altrimenti se la lunghezza della seconda dimensione di K è 3 allora....

        cls = lft(sys_ic,K,1,3);    % uso un controllore Hinf o mu

       %faccio la TRASF.LIN.FRATTA tra sys_ic e K---> do la prima
       %uscita di K all'ultimo ingresso di sys_ic e le ultime 3 uscite di
       %sys_ic le do ai primi 3 ingressi di K
    end

    omega = logspace(0,4,100);
    cls_g = ufrd(cls(1,1),omega);
    %Uncertain Frequency Response Data models (ufrd) ----
    %--->I modelli ufrd tengono traccia di come gli elementi incerti influenzano 
    %    la risposta in frequenza. Possono essere utilizzati 
    %     per una stabilità robusta e un'analisi delle prestazioni nel worst case.

%VALUTO LA STABILITA' ROBUSTA
opt = robopt('Display','on','Sensitivity','off');
[stabmarg,destabunc,report,info] = robuststab(cls_g,opt);

stabmarg %Stampiamo i margini di stabilità(ovvero upper e lower bound e 
         %anche a frequenza in cui avviene l'instabilità
report %Stampo un report,cioè una descrizione testuale dell'analisi di robustezza ottenuta 

semilogx(info.MussvBnds(1,1),'r',info.MussvBnds(1,2),'b--')
grid
title('STABILITA ROBUSTA')
xlabel('Frequency (rad/s)')
ylabel('mu')
legend('\mu-upper bound','\mu-lower bound','4')


%%
%ANALISI delle PRESTAZIONI NOMINALI e ROBUSTE 

if size(K,2) == 2
   csys = lft(sys_ic_PD,K,1,2); % controllore PD
elseif size(K,2) == 3
   csys = lft(sys_ic,K,1,3);    % controllore Hinf o mu
end
omega = logspace(-1,4,200);

% PRESTAZIONI NOMINALI (senza incertezze)
figure(1)
sv = sigma(csys.Nominal,omega);
semilogx(omega,sv(1,:),'r',omega,sv(2,:),'b'),grid
title('Prestazioni NOMINALI')
xlabel('Frequency (rad/s)')

%PRESTAZIONI ROBUSTE
csys_g = ufrd(csys,omega);

opt = robopt('Display','on','Sensitivity','off');
[perfmarg,perfmargunc,report,info] = robustperf(csys_g,opt);

%Stampo nel workspace:
perfmarg %margini di prestazione, ovvero limite superiore e inferiore dei margini di prestazione 
         % e inoltre perfmarg mi dice la frequenza in cui avviene
         % la peggiore degradazione delle performance
report %descrizione testuale delle performance di robustezza ottenute

figure(2)
semilogx(info.MussvBnds(1,1),'r',info.MussvBnds(1,2),'b--')
grid
title('Prestazioni ROBUSTE')
xlabel('Frequency (rad/s)')
ylabel('mu')
legend(' Upper bound',' Lower bound','1')


%%
%ADESSO vado a considerare il sistema o.l. completo per effettuare la
%simulazione

%Ingressi al controllore: 
%                     1)  ref
%                     2)  theta + noise1 = ys1
%                     3)  ddot(alpha) + noise2 = ys2


%Funzione di trasferimento dell'attuatore
nuWa = 1;
dnWa = [0.003   1];
gainWa = 1;
Wa = gainWa*tf(nuWa,dnWa);

ystemnames = ' G Wa Wn1 Wn2 ';
inputvar = '[ ref; dist; noise{2}; control ]';
temp = '[ G(1); G(2); G(3); G(4); ';
outputvar = [temp ' control;  ref; G(2) + Wn1; G(3) + Wn2 ]'];
input_to_G = '[ Wa - dist ]';
input_to_Wa = '[ control ]';
input_to_Wn1 = '[ noise(1) ]';
input_to_Wn2 = '[ noise(2) ]';
sim_ic = sysic
outputs = {'alpha' 'theta' 'ddalpha' 'wL' 'control' 'ref' 'y_s(1)' 'y_s(2)'};
sim_ic.OutputName = outputs;


%%
%Valuto le RISPOSTE TRANSITORIE del sistema a catena chiusa

clp = lft(sim_ic,K,1,3); %faccio la trasf. lin. fratta

ti = 0.001;     % incremento temporale                     
tfin1 = 1;
time1 = 0:ti:tfin1;
nstep1 = size(time1,2);
ref1(1:nstep1) = pi*time1(1:nstep1)/12-sin(2*pi*time1(1:nstep1))/24;

tfin2 = 3;      % tempo finale di simulazione
time2 = tfin1+ti:ti:tfin2;
nstep2 = size(time2,2);
ref2(1:nstep2) = pi/12; %posizione finale desiderata

time = [time1, time2];
ref = [ref1,ref2]; 

dist(1:nstep1+nstep2) = 0;
noise1(1:nstep1+nstep2) = 0;
noise2(1:nstep1+nstep2) = 0;
nsample = 30;

clp_30 = usample(clp,nsample); %usample=Generates random samples of uncertain matrices or systems
for i = 1:nsample
    [y,t] = lsim(clp_30(1:5,1:4,i),[ref',dist',noise1',noise2'],time);
%
    alpha = y(:,1);
    theta = y(:,2);
    figure(1)
    plot(t,ref,'b--',t,alpha,'r-',t,theta,'c-.'), grid
    hold on
%
    wl = y(:,4);
    figure(2)
    plot(t,wl,'r-'), grid
    hold on
%
    ur = y(:,5);
    figure(3)
    plot(t,ur,'r-'), grid
    hold on
end

figure(1)
grid
title('Risposta transitoria del sistema a catena chiusa')
xlabel('Time (secs)')
ylabel('ref, \alpha, \theta')
legend('ref','\alpha','\theta','4')
hold off

figure(2)
grid
title('Risposta transitoria della deflessione della punta (w_L)')
xlabel('Time (secs)')
ylabel('w_L (m)')
hold off
figure(3)
grid
title('Azione di controllo del controllore mu progettao')
xlabel('Time (secs)')
ylabel('u (V)')
hold off

clear ref1, clear ref2
clear noise1, clear noise2

%%
%Valuto le RISPOSTE IN FREQUENZA del sistema a catena chiusa

%clp = lft(sim_ic,K,1,3); %faccio la trasf. lin. fratta

ref_loop = clp(1,1); %considero il sistema CON INPUT REF e OUTPUT ALPHA
omega = logspace(0,3,100);
figure(1)
bode(ref_loop,'b-',M,'r--',omega), grid
title('Diagramma di Bode del sistema a catena chiusa')
legend('Closed-loop system','Model','3')

% RISPOSTA IN FREQUENZA di wL
wl_loop = clp(4,1); % from ref to wL
omega = logspace(-1,3,100);
figure(2)
bode(wl_loop,omega), grid
title('Risposta in frequenza di wL')

% Sensibilità di uscita al disturbo
sen_loop = clp(1,2); %considero il sistema CON INPUT DIST e OUTPUT ALPHA
omega = logspace(-3,3,300);
figure(3)
bodemag(sen_loop,'r',omega), grid
title('Sensibilità del disturbo')

% Sensibilità di uscita al rumore 1
noise1_loop = clp(1,3); %considero il sistema CON INPUT NOISE1 e OUTPUT ALPHA
omega = logspace(-2,3,100);
figure(4)
bodemag(noise1_loop,'r-',omega), grid
title('Sensibilità del rumore 1')

%Vari altri plot
%{
% Sensibilità di uscita al rumore 2
noise2_loop = clp(1,4); % %considero il sistema CON INPUT NOISE2 e OUTPUT ALPHA
omega = logspace(-2,3,100);
figure(5)
bodemag(noise2_loop,'r-',omega), grid
title('Sensibilità del rumore 2')

% Risposta in frequenza del controllore
K_1 = K(1,1);
K_2 = K(1,2);
K_3 = K(1,3);
omega = logspace(-3,3,300);
figure(6)
bode(K_1,'r-',K_2,'b--',K_3,'m-.',omega), grid
title('Diagramma di Bode del controllore')
legend('K_{ r}','K_{ \vartheta}','K_{ d^2\alpha/dt^2}','3')

% open-loop frequency response
G_theta_u = sim_ic([6:8],5);
L = K*G_theta_u;
omega = logspace(-2,3,100);
figure(7)
bode(L,omega), grid
title('Open-loop Bode plot')
%}


%%
%Vediamo se possiamo RIDURRE L'ORDINE DEL CONTROLLORE (prima era di 17)

[Kred,redinfo] = reduce(K,12); %12 = ordine desiderato

sigma(K,'r',Kred,'b--'),grid
title('Risposta in frequenza del controllore di ordine pieno e di ordine ridotto')
legend(' Full-order controller',' Reduced-order controller','3')

%confrontando le due risposte in frequenza il controllore ridotto
%è una buona approssimazione di quello pieno

%Errore di riduzione del modello
[gap,nugap] = gapmetric(K,Kred);

K = Kred;
[Ak,Bk,Ck,Dk] = ssdata(K);


%%
%ADESSO andiamo a verificare come si comporta il nostro controllore con
%il sistema non lineare

%prendo il controllore [Ak,Bk,Ck,Dk] = ssdata(K);

%e imposto i parametri dei filtri
kf1 = 0.001;   Tf11 = 0.5; Tf12 = 0.005;
kf2 = 0.00001; Tf21 = 1;   Tf22 = 0.01;

nls_flm


%%
%Confronto tra la deflessione elastica del manipolatore flessibile,
%in presenza di un controllore mu e di un controllore PD
 
p3d_con_PD_flm

s3d_con_controlloremu_flm

    