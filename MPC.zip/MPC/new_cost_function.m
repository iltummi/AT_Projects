function CF_val = new_cost_function(Utry)
 
global PIL_ITA_pc VSL Lvect X0 N gamma_I gamma_A gamma_Q gamma_H alpha_I alpha_H u

Lvect = Utry;

t = 0:1:N-1;
XX = ode3('gatto',t,X0);
 
S = XX(:,1);
E = XX(:,2);
P = XX(:,3);
I = XX(:,4);
A = XX(:,5); 
D = XX(:,9);

CF_val = sum(u.*PIL_ITA_pc.*Lvect'.*(S+E+P+I+A) + (1-u).*D.*VSL);
    