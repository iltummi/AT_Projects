function [vv,veq] = vincoli_open_loop(Utry)

global delta_E delta_P sigma eta gamma_I gamma_A gamma_Q gamma_H alpha_I alpha_H 
global xi X0 beta_P beta_I beta_A N Lvect theta beta_P_r beta_I_r beta_A_r MaxdeltaI deltaT vv
   
    idx = 1;
    Lvect = Utry; 
    XX = ode3('gatto',0:1:N-1, X0); 
    
    for i = 0:deltaT:N-deltaT
     
        high_I = mean(diff(XX(i+1:i+deltaT, 4)));
            
        vv(idx,1) = high_I - MaxdeltaI; 
        
        idx = idx + 1;
    end
    
    veq = [];