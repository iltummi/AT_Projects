clear all
close all
clc

%% parameters
global delta_E delta_P sigma eta gamma_I gamma_A gamma_Q gamma_H alpha_I alpha_H 
global xi X0 beta_P beta_I beta_A N Lvect theta beta_P_r beta_I_r beta_A_r MaxdeltaI deltaT vv L N_START
global PIL_ITA_pc VSL theta u
parameters_real;

%% Difference between Real and Non-real model

N = 200;
Lvect = zeros(1,N);
time = 0:1:N-1;

XR = ode3('gatto_real',time,X0); %real
XM = ode3('gatto',time,X0);  %model

XR_nL = XR;

figure
t3 = tiledlayout(9,1);
nexttile; plot(time,XR(:,1).*100); hold on; plot(time,XM(:,1).*100,'r');
ylabel('S (%)')
nexttile; plot(time,XR(:,2).*100); hold on; plot(time,XM(:,2).*100,'r');
ylabel('E (%)')
nexttile; plot(time,XR(:,3).*100); hold on; plot(time,XM(:,3).*100,'r');
ylabel('P (%)')
nexttile; plot(time,XR(:,4).*100); hold on; plot(time,XM(:,4).*100,'r');
ylabel('I (%)')
nexttile; plot(time,XR(:,5).*100); hold on; plot(time,XM(:,5).*100,'r');
ylabel('A (%)')
nexttile; plot(time,XR(:,6).*100); hold on; plot(time,XM(:,6).*100,'r');
ylabel('H (%)')
nexttile; plot(time,XR(:,7).*100); hold on; plot(time,XM(:,7).*100,'r');
ylabel('Q (%)')
nexttile; plot(time,XR(:,8).*100); hold on; plot(time,XM(:,8).*100,'r');
ylabel('R (%)')
nexttile; plot(time,XR(:,9).*100); hold on; plot(time,XM(:,9).*100,'r');
ylabel('D (%)')
legend({'real' 'model'},'orientation','horizontal','location','southoutside');
title(t3,'real-model difference');xlabel(t3,'Time (days)');

%% No lockdown for first 14 days

N_START = 14;
Lvect = zeros(1,N_START);
time = 0:1:N_START-1;
XR = ode3('gatto_real',time,X0); %real
XM = ode3('gatto',time,X0);  %model

X0R = XR(N_START,:)'; %new initial conditions;
X0M = XM(N_START,:)';

XX_real = XR(1:N_START,:); 
XX_model = XM(1:N_START,:); 
Lfinal = zeros(N_START,1); 

%% Closed loop MPC

Nc = 200 - N_START;

N = 90; % prediction horizon

time = 0:1:N-1;
deltaT = 14;

MaxdeltaI = 0.0005;

lb = zeros(N,1); % lower bounds
ub = 0.7.*ones(N,1); % upper bounds

DDD = zeros(9,1); 

tic
for jj = 0:deltaT:Nc-1
    
    jj
    
    % MATCHING (observable states)
    DDD = XR(end,:) - XM(end,:); 
    X0M(1) = X0M(1) + DDD(1); % S 
    X0M(4) = X0M(4) + DDD(4); % I
    X0M(6) = X0M(6) + DDD(6); % H
    X0M(7) = X0M(7) + DDD(7); % Q
    X0M(8) = X0M(8) + DDD(8); % R
    X0M(9) = X0M(9) + DDD(9); % D
   
    X0 = X0M;
    
    options = optimoptions('ga','Display','iter','ConstraintTolerance',1e-2,'MaxGenerations',20,'NonlinearConstraintAlgorithm','penalty');
    [Uvec,fval,exitflag] = ga(@new_cost_function,N,[],[],[],[],lb,ub,@vincoli_open_loop,options); 

    Lvect = Uvec(1:deltaT+1);
   
    XR = ode3('gatto_real',1:1:deltaT,X0R); 
    XM = ode3('gatto',1:1:deltaT,X0M); 
    
    X0R = XR(end,:)'; % new initial condition of real model
    X0M = XM(end,:)'; % new initial condition of model

    XX_real = [XX_real; XR(1:end,:)];
    XX_model = [XX_model; XM(1:end,:)];
    
    Lfinal = [Lfinal; Lvect(1:end-1)']; % Optimal lockdown 
end
toc

%
N = 200
Lfinal = Lfinal(1:N);
XX_real = XX_real(1:N,:);
XX_model = XX_model(1:N,:);

%% Plot
time = 0:1:N-1;
figure('Name','MPC LOCKDOWN STRATEGY')
t3 = tiledlayout(10,1);
nexttile; plot(time,Lfinal.*100,'r'); ylabel('Lockdown (%)'); ylim([0 100]); %xlim([0 200]);
nexttile; plot(time,XX_real(:,1).*100); hold on; plot(time,XX_model(:,1).*100,'r'); plot(time,XR_nL(:,1).*100,'g'); xlim([0 200]);
ylabel('S (%)')
nexttile; plot(time,XX_real(:,2).*100); hold on; plot(time,XX_model(:,2).*100,'r'); plot(time,XR_nL(:,2).*100,'g'); xlim([0 200]);
ylabel('E (%)')
nexttile; plot(time,XX_real(:,3).*100); hold on; plot(time,XX_model(:,3).*100,'r'); plot(time,XR_nL(:,3).*100,'g'); xlim([0 200]);
ylabel('P (%)')
nexttile; plot(time,XX_real(:,4).*100); hold on; plot(time,XX_model(:,4).*100,'r'); plot(time,XR_nL(:,4).*100,'g'); xlim([0 200]);
ylabel('I (%)')
nexttile; plot(time,XX_real(:,5).*100); hold on; plot(time,XX_model(:,5).*100,'r'); plot(time,XR_nL(:,5).*100,'g'); xlim([0 200]);
ylabel('A (%)')
nexttile; plot(time,XX_real(:,6).*100); hold on; plot(time,XX_model(:,6).*100,'r'); plot(time,XR_nL(:,6).*100,'g'); xlim([0 200]);
ylabel('H (%)')
nexttile; plot(time,XX_real(:,7).*100); hold on; plot(time,XX_model(:,7).*100,'r'); plot(time,XR_nL(:,7).*100,'g'); xlim([0 200]);
ylabel('Q (%)')
nexttile; plot(time,XX_real(:,8).*100); hold on; plot(time,XX_model(:,8).*100,'r'); plot(time,XR_nL(:,8).*100,'g'); xlim([0 200]);
ylabel('R (%)')
nexttile; plot(time,XX_real(:,9).*100); hold on; plot(time,XX_model(:,9).*100,'r'); plot(time,XR_nL(:,9).*100,'g'); xlim([0 200]);
ylabel('D (%)')
legend({'real' 'model' 'Real no lockdown'},'orientation','horizontal','location','southoutside');
title(t3,'closed loop MPC');xlabel(t3,'Time (days)');

figure('Name','COMPARISON REAL VS MODEL')
t4 = tiledlayout(10,1);
nexttile; plot(time,Lfinal.*100,'r'); ylabel('Lockdown (%)'); ylim([0 100]); xlim([0 200]);
nexttile; plot(time,XX_real(:,1).*100); hold on; plot(time,XX_model(:,1).*100,'r'); xlim([0 200]);
ylabel('S (%)')
nexttile; plot(time,XX_real(:,2).*100); hold on; plot(time,XX_model(:,2).*100,'r'); xlim([0 200]);
ylabel('E (%)')
nexttile; plot(time,XX_real(:,3).*100); hold on; plot(time,XX_model(:,3).*100,'r'); xlim([0 200]);
ylabel('P (%)')
nexttile; plot(time,XX_real(:,4).*100); hold on; plot(time,XX_model(:,4).*100,'r'); xlim([0 200]);
ylabel('I (%)')
nexttile; plot(time,XX_real(:,5).*100); hold on; plot(time,XX_model(:,5).*100,'r'); xlim([0 200]);
ylabel('A (%)')
nexttile; plot(time,XX_real(:,6).*100); hold on; plot(time,XX_model(:,6).*100,'r'); xlim([0 200]);
ylabel('H (%)')
nexttile; plot(time,XX_real(:,7).*100); hold on; plot(time,XX_model(:,7).*100,'r'); xlim([0 200]);
ylabel('Q (%)')
nexttile; plot(time,XX_real(:,8).*100); hold on; plot(time,XX_model(:,8).*100,'r'); xlim([0 200]);
ylabel('R (%)')
nexttile; plot(time,XX_real(:,9).*100); hold on; plot(time,XX_model(:,9).*100,'r'); xlim([0 200]);
ylabel('D (%)')
legend({'real' 'model'},'orientation','horizontal','location','southoutside');
title(t4,'closed loop MPC');xlabel(t4,'Time (days)');

