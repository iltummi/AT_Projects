t1=size(Lfinal);
t2=t1(1);
 
%% Plot
time = 0:1:t2-1;
time = time';
 
time3 = 0:1:200-1;
time3=time3';

figure('Name','MPC LOCKDOWN STRATEGY')
t3 = tiledlayout(10,1);
nexttile; plot(time,Lfinal.*100,'r'); ylabel('Lockdown (%)'); ylim([0 100]);
nexttile; plot(time,XX_real(:,1).*100); hold on; plot(time,XX_model(:,1).*100,'r'); plot(time3,XR_nL(:,1).*100,'g'); ylim([0 110]);
ylabel('S (%)')
nexttile; plot(time,XX_real(:,2).*100); hold on; plot(time,XX_model(:,2).*100,'r'); plot(time3,XR_nL(:,2).*100,'g');
ylabel('E (%)')
nexttile; plot(time,XX_real(:,3).*100); hold on; plot(time,XX_model(:,3).*100,'r'); plot(time3,XR_nL(:,3).*100,'g');
ylabel('P (%)')
nexttile; plot(time,XX_real(:,4).*100); hold on; plot(time,XX_model(:,4).*100,'r'); plot(time3,XR_nL(:,4).*100,'g');
ylabel('I (%)')
nexttile; plot(time,XX_real(:,5).*100); hold on; plot(time,XX_model(:,5).*100,'r'); plot(time3,XR_nL(:,5).*100,'g');
ylabel('A (%)')
nexttile; plot(time,XX_real(:,6).*100); hold on; plot(time,XX_model(:,6).*100,'r'); plot(time3,XR_nL(:,6).*100,'g');
ylabel('H (%)')
nexttile; plot(time,XX_real(:,7).*100); hold on; plot(time,XX_model(:,7).*100,'r'); plot(time3,XR_nL(:,7).*100,'g');
ylabel('Q (%)')
nexttile; plot(time,XX_real(:,8).*100); hold on; plot(time,XX_model(:,8).*100,'r'); plot(time3,XR_nL(:,8).*100,'g');
ylabel('R (%)')
nexttile; plot(time,XX_real(:,9).*100); hold on; plot(time,XX_model(:,9).*100,'r'); plot(time3,XR_nL(:,9).*100,'g');
ylabel('D (%)')
legend({'real' 'model' 'Real no lockdown'},'orientation','horizontal','location','southoutside');
title(t3,'closed loop MPC effect');xlabel(t3,'Time (days)');

figure('Name','COMPARISON REAL VS MODEL')
t3 = tiledlayout(10,1);
nexttile; plot(time,Lfinal.*100,'r'); ylabel('Lockdown (%)'); ylim([0 100]);
nexttile; plot(time,XX_real(:,1).*100); hold on; plot(time,XX_model(:,1).*100,'r'); 
ylabel('S (%)')
nexttile; plot(time,XX_real(:,2).*100); hold on; plot(time,XX_model(:,2).*100,'r'); 
ylabel('E (%)')
nexttile; plot(time,XX_real(:,3).*100); hold on; plot(time,XX_model(:,3).*100,'r'); 
ylabel('P (%)')
nexttile; plot(time,XX_real(:,4).*100); hold on; plot(time,XX_model(:,4).*100,'r'); 
ylabel('I (%)')
nexttile; plot(time,XX_real(:,5).*100); hold on; plot(time,XX_model(:,5).*100,'r'); 
ylabel('A (%)')
nexttile; plot(time,XX_real(:,6).*100); hold on; plot(time,XX_model(:,6).*100,'r'); 
ylabel('H (%)')
nexttile; plot(time,XX_real(:,7).*100); hold on; plot(time,XX_model(:,7).*100,'r'); 
ylabel('Q (%)')
nexttile; plot(time,XX_real(:,8).*100); hold on; plot(time,XX_model(:,8).*100,'r'); 
ylabel('R (%)')
nexttile; plot(time,XX_real(:,9).*100); hold on; plot(time,XX_model(:,9).*100,'r');
ylabel('D (%)')
legend({'real' 'model'},'orientation','horizontal','location','southoutside');
title(t3,'Model vs Real');xlabel(t3,'Time (days)');