from robot import Robot
from prob2 import Prob2

class Ottimizzatore:
    '''Helper class for the end user'''
    def load_robot(self, urdf_path, root, tip, **kwargs):
        '''Loading robot info from URDF'''
        self.robot = Robot(urdf_path, root, tip, **kwargs)
        return self.robot

    def load_problem(self, cost_func, control_steps, initial_cond, **kwargs):
        self.problema = Prob2(self.robot, cost_func, control_steps, initial_cond, **kwargs)
        return self.problema

    def ilqr(self, x0, N, max_iter, regu_init):
        x_trj, u_trj, cost_trace, regu_trace, redu_ratio_trace, redu_trace, q0_measured, q1_measured = self.problema.run_ilqr(x0, N, max_iter, regu_init)
        return x_trj, u_trj, cost_trace, regu_trace, redu_ratio_trace, redu_trace, q0_measured, q1_measured

ottimizzatore = Ottimizzatore()
