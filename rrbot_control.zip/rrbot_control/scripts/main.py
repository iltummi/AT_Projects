#!/usr/bin/env python3

import pathlib
from ottimizzatore import ottimizzatore
import matplotlib.pyplot as plt
import numpy as np
import casadi as cs
import rospy

#from pytictoc import TicToc
#tt = TicToc() #create instance of class

# Initiate node for controlling joint1 and joint2 positions.
rospy.init_node('joint_effort_write_states_read')
# rate = rospy.Rate(20)  # 100 Hz

# URDF options
urdf_path = pathlib.Path(__file__).parent.joinpath('urdf', 'rrbot.urdf').absolute()
root = "link1"
end = "link3"

def my_trajectory_target(t):
    #q = [0, 0]
    #q = [3.14 / 2 * (t / 10.0), 3.14/2]
    q = [0.5*np.cos(t),0.5*np.sin(t)]
    #q = [t*0.5,t*0.5]
    # q = [3.14 / 2 , 3.14 / 2]
    return q

def my_cost_func(q, qd, qdd, ee_pos, u, t):
    return q.T @ q * 100 + u.T @ u / 10 ** 5

def traiettoria_desiderata(time_horizon,steps):
    dt = time_horizon/steps
    q_des_0 = []
    q_des_1 = []

    for i in range(steps):
        q = my_trajectory_target(i*dt)
        q_des_0.append(q[0])
        q_des_1.append(q[1])

    return q_des_0, q_des_1

in_cond = [0] * 4 #[3.14/2, 3.14/2, 0, 0]

time_horizon = 30.0
steps = 300
max_iterazione = steps

ottimizzatore.load_robot(urdf_path, root, end)

ottimizzatore.load_problem(
    cost_func=my_cost_func,
    control_steps=steps,
    initial_cond=in_cond,
    trajectory_target=my_trajectory_target,
    time_horizon=time_horizon
)

#tt.tic() #Start timer
x_trj, u_trj, cost_trace, regu_trace, redu_ratio_trace, redu_trace, q0_measured, q1_measured = ottimizzatore.ilqr(x0=in_cond, N=steps, max_iter=max_iterazione, regu_init=100)
#tt.toc() #Time elapsed since t.tic()



def casadi2nparray(casadi_array):
    '''Convert Casadi MX vectors (optimal solutions) in numpy arrays'''
    list = [np.array(el).flatten() for el in casadi_array]
    return np.array(list)

cost_trace = casadi2nparray(cost_trace)

redu_trace = casadi2nparray(redu_trace)

plt.figure()
plt.plot(q0_measured)
plt.title('q0_measured')
plt.show()

plt.figure()
plt.plot(q1_measured)
plt.title('q1_measured')
plt.show()

matrx_x = cs.DM(x_trj)

a1 = [matrx_x[:, 0]]
a2 = [matrx_x[:, 1]]
a3 = [matrx_x[:, 2]]
a4 = [matrx_x[:, 3]]

a1plot = casadi2nparray(a1)
a2plot = casadi2nparray(a2)
a3plot = casadi2nparray(a3)
a4plot = casadi2nparray(a4)

q_des_0, q_des_1 = traiettoria_desiderata(time_horizon,steps)

plt.figure()

plt.subplot(4,1,1)
plt.plot(a1plot.T)
plt.ylabel('q0')
plt.xlabel('steps')
plt.plot(np.array(q_des_0))

plt.subplot(4,1,2)
plt.plot(a2plot.T)
plt.ylabel('q1')
plt.xlabel('steps')
plt.plot(np.array(q_des_1))

plt.subplot(4,1,3)
plt.plot(a3plot.T)
plt.xlabel('steps')
plt.ylabel('q0_dot')

plt.subplot(4,1,4)
plt.plot(a4plot.T)
plt.ylabel('q1_dot')
plt.xlabel('steps')

plt.show()


plt.figure()

matrx_u = cs.DM(u_trj)

b1 = [matrx_u[:, 0]]
b2 = [matrx_u[:, 1]]

b1plot = casadi2nparray(b1)
b2plot = casadi2nparray(b2)

plt.subplot(2,1,1)
plt.plot(b1plot.T)
plt.xlabel('steps')
plt.ylabel('u0')
plt.title('coppie ottime link 0')

plt.subplot(2,1,2)
plt.plot(b2plot.T)
plt.xlabel('steps')
plt.ylabel('u1')
plt.title('coppie ottime link 1')
plt.show()

plt.figure()
plt.plot(cost_trace) 
plt.title('Cost trace')
plt.show()

plt.figure()
plt.plot(redu_trace)
plt.title('Redu trace')


plt.show()


