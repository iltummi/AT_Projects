#!/usr/bin/env python3

import casadi as cs
import numpy as np
import rospy

from std_msgs.msg import Float64
from sensor_msgs.msg import JointState

joint_states1 = []
joint_states2 = []
joint_velocity1 = []
joint_velocity2 = []

def callback(data):
    joint_states1.append(data.position[0])
    joint_states2.append(data.position[1])
    joint_velocity1.append(data.velocity[0])
    joint_velocity2.append(data.velocity[1])

class Prob2:
    def __init__(self, robot, cost_func, control_steps, initial_cond, trajectory_target=None, time_horizon=None,
                 final_term_cost=None, rk_interval=4):
        """ Solve method. Takes the problems conditions as input and set up its solution"""
        self.robot = robot

        # Store Robot's useful attributes as Problem Attributes.
        self.__dict__.update(self.robot.__dict__)

        # Store Values
        self.t = cs.SX.sym("t", 1)
        self.traj, self.traj_dot = self.format_trajectory(trajectory_target, self.t)
        self.cost_func = cost_func
        self.T = cs.MX.sym("T", 1) if time_horizon == None else time_horizon
        self.N = control_steps
        self.rk_intervals = rk_interval

        self.final_term_cost = final_term_cost
        if self.final_term_cost is not None:
            l_final_x = cs.jacobian(self.final_term_cost, self.x)
            l_final_xx = cs.jacobian(l_final_x, self.x)
            self.l_final_x = cs.Function('l_final_x',[self.x],[l_final_x])
            self.l_final_xx = cs.Function('l_final_xx',[self.x],[l_final_xx])

        # If we get just the position, we set the initial velocity to zero
        if len(initial_cond) == 2 * self.num_joints:
            self.initial_cond = initial_cond
        elif len(initial_cond) == self.num_joints:
            self.initial_cond = initial_cond + [0] * self.num_joints
        else:
            raise ValueError('Initial Conditions should be {} item long: (q, q_dot)'.format(2 * self.num_joints))

        # Calculating the differential equations
        self.f = self._get_diff_eq()
        
        # Rewriting the differential equation symbolically with Range-Kutta 4th order
        self.F, self.F_x, self.F_u = self._rk4(self.f, self.rk_intervals)

        self.l_x, self.l_u, self.l_xx, self.l_ux, self.l_xu, self.l_uu = self.derivates()

    def _get_diff_eq(self):
        '''Function that returns the RhS of the differential equations. See the papers for additional info'''
        
        RHS = []

        # RHS that's in common for all cases
        rhs1 = self.q_dot
        rhs2 = self.M_inv @ (-self.Cq - self.G - self.Fd @ self.q_dot - self.Ff @ cs.sign(self.q_dot))

        # State  variable
        self.x = cs.vertcat(self.q, self.q_dot)
        self.num_state_var = self.num_joints

        # Adjusting RHS for classic robot modeling, without any SEA
        rhs2 += self.M_inv @ self.u
        RHS = [rhs1, rhs2]

        # Evaluating q_ddot, in order to handle it when given as an input of cost function or constraints
        self.q_ddot_val = self._get_joints_accelerations(rhs2)

        # Setting the relationship
        self.x_dot = cs.vertcat(*RHS)

        # Defining the differential equation
        f = cs.Function('f',    [self.x, self.u],  # inputs
                                [self.x_dot])  # outputs

        return f

    def format_trajectory(self, traj, t):
        '''Function that formats the trajectory'''
        # If the user gave the also the wanted qd
        if isinstance(traj(t)[0], list):
            traj_dot = cs.vertcat(*traj(t)[1])
            traj = cs.vertcat(*traj(t)[0])
        # If the user just gave q desired then we set qd desired to be zero
        else:
            zeros = lambda t: [0]*self.num_joints
            traj_dot = cs.vertcat(*zeros(t))
            traj = cs.vertcat(*traj(t))
        return traj, traj_dot

    def _get_joints_accelerations(self, rhs2):
        '''Returns a CASaDi function that maps the q_ddot from other joints info.'''
        q_ddot_val = cs.Function('q_ddot_val', [self.q, self.q_dot, self.u], [rhs2])
        return q_ddot_val

    def _rk4(self, f, m):
        '''Applying 4th Order Range Kutta for N steps and m Range Kutta intervals'''

        # Defining the time step
        dt = self.T / self.N / m

        # Variable definition for RK method
        X0 = cs.MX.sym('X0', self.num_state_var * 2)
        U = cs.MX.sym('U', self.num_joints)
        t = cs.MX.sym('t', 1)

        # Initial value
        X = X0

        # Integration - 4th order Range Kutta, done m times
        for j in range(m):
            k1 = f(X, U)
            k2 = f(X + dt / 2 @ k1, U)
            k3 = f(X + dt / 2 @ k2, U)
            k4 = f(X + dt @ k3, U)
            # Update the state
            X = X + dt / 6 @ (k1 + 2 * k2 + 2 * k3 + k4)

        # Getting the differential equation discretized but still symbolical. Paper for more info
        self.F = cs.Function('F', [X0, U], [X], ['x0', 'p'], ['xf'])

        F_new = self.F(self.x, self.u)

        F_x = cs.jacobian(F_new, self.x)
        F_u = cs.jacobian(F_new, self.u)

        self.F_x = cs.Function('F_x',[self.x, self.u, self.t],[F_x])
        self.F_u = cs.Function('F_u',[self.x, self.u, self.t],[F_u])

        return self.F, self.F_x, self.F_u
        
    def rollout(self, x0, u_traj, N):
        
        x_i = x0
        x_traj = cs.DM.zeros((N, self.num_joints * 2))
        
        for i in range(0, N-1):
            x_i = self.F(x_i, u_traj[i,:])
            x_traj[i,0] = x_i[0]
            x_traj[i,1] = x_i[1]
            x_traj[i,2] = x_i[2]
            x_traj[i,3] = x_i[3]

        return x_traj

    def derivates(self):
        q_ddot_J = self.q_ddot_val(self.q,self.q_dot, self.u)

        l = self.cost_func(self.q - self.traj,
                           self.q_dot - self.traj_dot,
                           q_ddot_J,
                           self.ee_pos(self.q),
                           self.u,
                           self.t)

        self.l = cs.Function('l',[self.x, self.u, self.t],[l])

        l_x = cs.jacobian(l, self.x)
        l_u = cs.jacobian(l, self.u)
        l_xx = cs.jacobian(l_x, self.x)
        l_ux = cs.jacobian(l_u, self.x)
        l_xu = cs.jacobian(l_x, self.u)
        l_uu = cs.jacobian(l_u, self.u)

        self.l_x = cs.Function('l_x',[self.x, self.u, self.t],[l_x])
        self.l_u = cs.Function('l_u',[self.x, self.u, self.t],[l_u])
        self.l_xx = cs.Function('l_xx',[self.x, self.u, self.t],[l_xx])
        self.l_ux = cs.Function('l_x',[self.x, self.u, self.t],[l_ux])
        self.l_xu = cs.Function('l_xu',[self.x, self.u, self.t],[l_xu])
        self.l_uu = cs.Function('l_uu',[self.x, self.u, self.t],[l_uu])

        return self.l_x, self.l_u, self.l_xx, self.l_ux, self.l_xu, self.l_uu

    def stage(self, misure, ingressi, time):

        l_x = self.l_x([np.double(misure[0]), np.double(misure[1]), np.double(misure[2]), np.double(misure[3])], [np.double(ingressi[0]), np.double(ingressi[1])], [time])
        l_u = self.l_u([np.double(misure[0]), np.double(misure[1]), np.double(misure[2]), np.double(misure[3])], [np.double(ingressi[0]), np.double(ingressi[1])], [time])
        l_xx = self.l_xx([np.double(misure[0]), np.double(misure[1]), np.double(misure[2]), np.double(misure[3])], [np.double(ingressi[0]), np.double(ingressi[1])], [time])
        l_ux = self.l_ux([np.double(misure[0]), np.double(misure[1]), np.double(misure[2]), np.double(misure[3])], [np.double(ingressi[0]), np.double(ingressi[1])], [time])
        l_xu = self.l_xu([np.double(misure[0]), np.double(misure[1]), np.double(misure[2]), np.double(misure[3])], [np.double(ingressi[0]), np.double(ingressi[1])], [time])
        l_uu = self.l_uu([np.double(misure[0]), np.double(misure[1]), np.double(misure[2]), np.double(misure[3])], [np.double(ingressi[0]), np.double(ingressi[1])], [time])

        F_x = self.F_x([np.double(misure[0]), np.double(misure[1]), np.double(misure[2]), np.double(misure[3])], [np.double(ingressi[0]), np.double(ingressi[1])], [time])
        F_u = self.F_u([np.double(misure[0]), np.double(misure[1]), np.double(misure[2]), np.double(misure[3])], [np.double(ingressi[0]), np.double(ingressi[1])], [time])

        return l_x, l_u, l_xx, l_ux, l_xu, l_uu, F_x, F_u

    def cost_stage(self, misure, ingressi, time):

        J2_sub = self.l([np.double(misure[0]), np.double(misure[1]), np.double(misure[2]), np.double(misure[3])], [np.double(ingressi[0]), np.double(ingressi[1])], [time]) 

        return J2_sub

    def cost_final(self, x):
        if self.final_term_cost is not None:
            J1_sub = cs.substitute(self.final_term_cost, self.x, x)
        else:
            J1_sub = 0
        return J1_sub

    def final(self, misure):
        if self.final_term_cost is not None:
            l_final_x = self.l_final_x([misure[0],misure[1],misure[2],misure[3]])
            l_final_xx = self.l_final_xx([misure[0],misure[1],misure[2],misure[3]])
        else:
            l_final_x = cs.DM.zeros(self.x.shape[0],self.x.shape[1])  #4x1
            l_final_xx = cs.DM.zeros(self.x.shape[0],self.x.shape[0]) #4x4
        return l_final_x, l_final_xx

    def cost_trj(self, x_traiet, u_traiet):
        totale = 0.0
        dentro_int = 0.0
        dt = self.T / self.N

        for i in range(self.N-1):
            dentro_int += self.cost_stage(x_traiet[i,:], u_traiet[i,:], i*dt)

        totale = self.cost_final(x_traiet[-1]) + dentro_int
        return totale

    def Q_terms(self, l_x, l_u, l_xx, l_ux, l_xu, l_uu, F_x, F_u, V_x, V_xx):
        
        Q_x = l_x.T + F_x.T @ V_x
        Q_u = l_u.T + F_u.T @ V_x

        Q_xx = l_xx + F_x.T @ V_xx @ F_x
        Q_uu = l_uu + F_u.T @ V_xx @ F_u
        Q_xu = l_xu + F_x.T @ V_xx @ F_u
        Q_ux = l_ux + F_u.T @ V_xx @ F_x

        return Q_x, Q_u, Q_xx, Q_uu, Q_xu, Q_ux

    def V_terms(self, Q_x, Q_u, Q_xx, Q_uu, Q_xu, Q_ux):

        V_x = Q_x - Q_xu @ cs.inv(Q_uu) @ Q_u   #guarda l'invertibilità
        V_xx = Q_xx - Q_xu @ cs.inv(Q_uu) @ Q_ux

        return V_x, V_xx

    def gains(self, Q_uu, Q_u, Q_ux):
        k = - cs.inv(Q_uu) @ Q_u ##feed forward gain
        K = - cs.inv(Q_uu) @ Q_ux ## feed back
        
        return k, K

    def expected_cost_reduction(self, Q_u, Q_uu, k):
        return -Q_u.T @ k - 0.5 * k.T @ Q_uu @k

    def backward_pass(self, x_trj, u_trj, regu):

        k_trj = cs.DM.zeros(u_trj.shape[0], u_trj.shape[1])
        K_trj = cs.DM.zeros(u_trj.shape[0] * u_trj.shape[1], x_trj.shape[1])
        expected_cost_redu = 0

        l_final_x, l_final_xx = self.final(x_trj[(u_trj.shape[0]),:])
        V_x = l_final_x
        V_xx = l_final_xx
        dt = self.T/self.N

        for n in range(u_trj.shape[0]-1, -1, -1):
            l_x, l_u, l_xx, l_ux, l_xu, l_uu, F_x, F_u = self.stage(x_trj[n,:], u_trj[n,:], (n+1)*dt)
            Q_x, Q_u, Q_xx, Q_uu, Q_xu, Q_ux = self.Q_terms(l_x, l_u, l_xx, l_ux, l_xu, l_uu, F_x, F_u, V_x, V_xx)

            # We add regularization to ensure that Q_uu is invertible and nicely conditioned
            Q_uu_regu = Q_uu + np.eye(Q_uu.shape[0])*regu
            k, K = self.gains(Q_uu_regu, Q_u, Q_ux)
            k_trj[n,:] = k.T

            K_trj[n*2,:] = K[0,:]
            K_trj[n*2+1, :] = K[1, :]

            V_x, V_xx = self.V_terms(Q_x, Q_u, Q_xx, Q_uu, Q_xu, Q_ux)
            expected_cost_redu += self.expected_cost_reduction(Q_u, Q_uu, k)
            
        return k_trj, K_trj, expected_cost_redu

    def forward_pass(self, x_trj, u_trj, k_trj, K_trj):
        x_trj_new = cs.DM.zeros(x_trj.shape)
        x_trj_new[0,:] = x_trj[0,:]
        u_trj_new = cs.DM.zeros(u_trj.shape)
        dt = self.T/self.N
        
        for n in range(u_trj.shape[0]):
            u_trj_new[n,:] = u_trj[n,:] + k_trj[n,:] + (K_trj[n*2:n*2+2,:] @ (x_trj_new[n,:] - x_trj[n,:]).T).T 
            x_trj_new[n+1,:] = self.F(x_trj_new[n,:], u_trj_new[n,:]).T

        return x_trj_new, u_trj_new

    def run_ilqr(self, x0, N, max_iter, regu_init):
        # First forward rollout
        u_trj = cs.DM.rand(N-1, self.num_joints)*0.0001
        x_trj = self.rollout(x0, u_trj, N)
        misure = x_trj
        total_cost = self.cost_trj(x_trj, u_trj)
        regu = regu_init
        max_regu = 10000
        min_regu = 0.01

        # Setup traces
        cost_trace = [total_cost]
        expected_cost_redu_trace = []
        redu_ratio_trace = [1]
        redu_trace = []
        regu_trace = [regu]

	    #Define publishers for each joint position controller commands.
        pub1 = rospy.Publisher('/rrbot/joint1_effort_controller/command', Float64, queue_size=10)
        pub2 = rospy.Publisher('/rrbot/joint2_effort_controller/command', Float64, queue_size=10)
        sub1 = rospy.Subscriber("/rrbot/joint_states", JointState, callback)
        rate = rospy.Rate(10)
        it = 0

        # for it in range(max_iter):
        while not (rospy.is_shutdown()) and (it < max_iter):

            # Backward and forward pass
            k_trj, K_trj, expected_cost_redu = self.backward_pass(x_trj, u_trj, regu) #qui x_trj sono le x_trj_new della forward
            #leggo x_trj dal robot e lo do alla forward
            misure[it,:] = [joint_states1[it], joint_states2[it], joint_velocity1[it], joint_velocity2[it]]
            x_trj_new, u_trj_new = self.forward_pass(misure, u_trj, k_trj, K_trj) #qui entrano x_trj = misure prese dal robot
            # calcolo le u_trj_new e le applico al robot
            if it<u_trj_new.shape[0]:
                pub1.publish(u_trj_new[it,0:1])
                pub2.publish(u_trj_new[it,1:2])
            it = it +1
            # Evaluate new trajectory
            total_cost = self.cost_trj(x_trj_new, u_trj_new)
            cost_redu = cost_trace[-1] - total_cost

            redu_ratio = cost_redu / abs(cs.DM(expected_cost_redu))
            # Accept or reject iteration
            # print(cost_redu)
            if cost_redu > 0:
               # Improvement! Accept new trajectories and lower regularization
               redu_ratio_trace.append(redu_ratio)
               cost_trace.append(total_cost)
               x_trj = x_trj_new
               u_trj = u_trj_new
               regu *= 0.7
            else:
               # Reject new trajectories and increase regularization
               regu *=2
               cost_trace.append(cost_trace[-1])
               redu_ratio_trace.append(0)
            regu = min(max(regu, min_regu), max_regu)
            regu_trace.append(regu)
            redu_trace.append(cost_redu)
           # Early termination if expected improvement is small
            if expected_cost_redu <= 1e-6:
                break
                #print(expected_cost_redu)
            rate.sleep()

        q0_measured = np.array(joint_states1)
        q1_measured = np.array(joint_states2)


        return x_trj, u_trj, cost_trace, regu_trace, redu_ratio_trace, redu_trace, q0_measured, q1_measured






    
    

